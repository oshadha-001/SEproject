package com.gtp.gtpproject;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GtPprojectApplication {

    public static void main(String[] args) {
        SpringApplication.run(GtPprojectApplication.class, args);
    }
}